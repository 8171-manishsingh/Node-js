import React from "react";

function Footer() {
  return <footer>&copy; by The Atomic Blog ✌️</footer>;
}

export default Footer;
