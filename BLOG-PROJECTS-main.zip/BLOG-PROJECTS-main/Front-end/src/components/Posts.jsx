import React from "react";
import List from "./Lists";

function Posts() {
  return (
    <section>
      <List />
    </section>
  );
}

export default Posts;
