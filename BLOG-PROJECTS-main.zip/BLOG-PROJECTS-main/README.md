# BLOG-PROJECTS
<a href="https://drive.google.com/file/d/1fynBriNoSxk37F7dyQXsXgE_-8x3D5il/view?usp=drive_link">video Link</a>

BLOG PROJECTS MERN Stack

Blog Management System 📝 | MERN Stack 🔐

A full-stack blog app with React.js frontend & Node.js + Express + MongoDB backend. Supports JWT Auth, role-based access (Admin/User), and full CRUD operations on blog posts. Features secure login, protected routes, and responsive UI. Perfect starter project for learning MERN stack authentication & authorization. 🚀
